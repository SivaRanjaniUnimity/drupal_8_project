# Media: Acquia DAM Example Configuration

This is an example module that will set up an initial configuration of the Acquia DAM module. Once it has been installed it may be uninstalled without issue.
